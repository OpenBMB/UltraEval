import os
import json

def combine_json_files(source_folder, output_json_file):
    data = []
    for file_name in os.listdir(source_folder):
        if file_name.endswith('.json'):
            file_path = os.path.join(source_folder, file_name)
            with open(file_path, 'r') as file:
                try:
                    json_content = json.load(file)
                    data.append(json_content)
                except json.JSONDecodeError:
                    print(f"Error decoding JSON from {file_name}")

    with open(output_json_file, 'w') as json_file:
        json.dump(data, json_file, indent=4)

def process_folders(parent_folder):
    for folder_name in os.listdir(parent_folder):
        folder_path = os.path.join(parent_folder, folder_name)
        if os.path.isdir(folder_path):
            output_json_file = os.path.join(parent_folder, folder_name + '.json')
            combine_json_files(folder_path, output_json_file)

parent_folder = './test'
process_folders(parent_folder)
