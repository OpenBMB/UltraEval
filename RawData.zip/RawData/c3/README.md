C3数据集-CLUE发行版

新增test1.1.json，作为CLUE1.1版本的测试集。
CLUE1.1与CLUE1.0区别：区别与原有的CLUE1.0，CLUE1.1在部分任务启用了新的测试集，训练集和验证集保持不变；CLUE1.0保留CMNLI自然语言推理任务
提交样例和说明，见github项目中的提交样例压缩包及其说明文件（README.md）

官网：www.CLUEbenchmarks.com
项目地址：https://github.com/CLUEbenchmark/CLUE
联系邮箱：CLUEbenchmark@163.com